package org.cscie88c.week2

object UtilFunctions {

  // complete the functions below
  def maximum(a: Int, b: Int): Int = if (a > b) a else b
  def average(a: Int, b: Int): Double = (a + b) / 2.0

}
